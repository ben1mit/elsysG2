var searchData=
[
  ['fill_5fmy_5fhttp_5fbuffer_5fdigit_65',['fill_my_http_buffer_digit',['../my__http__sender_8h.html#a95212498cf1a85a4f78379446284d3cf',1,'fill_my_http_buffer_digit(int new_measurement):&#160;my_http_sender.c'],['../my__http__sender_8c.html#a95212498cf1a85a4f78379446284d3cf',1,'fill_my_http_buffer_digit(int new_measurement):&#160;my_http_sender.c']]]
];
