var searchData=
[
  ['kdefaultclockspeed_81',['kDefaultClockSpeed',['../_i2_cbus_8hpp.html#a624a68a365962a86d7e798b94ffe89d6',1,'i2cbus']]],
  ['kdefaulttimeout_82',['kDefaultTimeout',['../_i2_cbus_8hpp.html#a703183fe882ed0288c212bb1f98be46f',1,'i2cbus']]]
];
