var searchData=
[
  ['knock_5finit_68',['knock_init',['../my__mpu__wrapper_8h.html#acc5b83b0150f6ab51324aa07c2819dec',1,'knock_init():&#160;my_mpu_wrapper.cpp'],['../my__mpu__wrapper_8cpp.html#acc5b83b0150f6ab51324aa07c2819dec',1,'knock_init():&#160;my_mpu_wrapper.cpp']]]
];
