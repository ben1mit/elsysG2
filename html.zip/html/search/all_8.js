var searchData=
[
  ['main_2ec_25',['main.c',['../hub__project_2main_2main_8c.html',1,'(Global Namespace)'],['../main__project_2main_2main_8c.html',1,'(Global Namespace)']]],
  ['my_5fclient_5fsend_5fmultiple_5fdigits_26',['my_client_send_multiple_digits',['../spp__client__demo_8h.html#ac5e90af3f5d31a6b8a3de3c8018a38c3',1,'my_client_send_multiple_digits(int num_to_send):&#160;spp_client_demo.c'],['../spp__client__demo_8c.html#ac5e90af3f5d31a6b8a3de3c8018a38c3',1,'my_client_send_multiple_digits(int num_to_send):&#160;spp_client_demo.c']]],
  ['my_5fclient_5fsend_5fsingle_5fdigit_27',['my_client_send_single_digit',['../spp__client__demo_8h.html#a4d3d3294bb009d4e75e7342dc2327bfd',1,'my_client_send_single_digit(int num_to_send):&#160;spp_client_demo.c'],['../spp__client__demo_8c.html#a4d3d3294bb009d4e75e7342dc2327bfd',1,'my_client_send_single_digit(int num_to_send):&#160;spp_client_demo.c']]],
  ['my_5fhttp_5fsender_2ec_28',['my_http_sender.c',['../my__http__sender_8c.html',1,'']]],
  ['my_5fhttp_5fsender_2eh_29',['my_http_sender.h',['../my__http__sender_8h.html',1,'']]],
  ['my_5fhttp_5fsender_5finit_30',['my_http_sender_init',['../my__http__sender_8h.html#a0a663676a8d0e9bc7e5370bfe46e4c1c',1,'my_http_sender_init():&#160;my_http_sender.c'],['../my__http__sender_8c.html#a0a663676a8d0e9bc7e5370bfe46e4c1c',1,'my_http_sender_init():&#160;my_http_sender.c']]],
  ['my_5fhttp_5fsender_5fsend_5fturbine_31',['my_http_sender_send_turbine',['../my__http__sender_8h.html#abe310355f3ccd6ab5bb6b7b33ac9a079',1,'my_http_sender_send_turbine(int turbin_id, int data[], size_t data_len):&#160;my_http_sender.c'],['../my__http__sender_8c.html#abe310355f3ccd6ab5bb6b7b33ac9a079',1,'my_http_sender_send_turbine(int turbin_id, int data[], size_t data_len):&#160;my_http_sender.c']]],
  ['my_5fmpu_5fwrapper_2ecpp_32',['my_mpu_wrapper.cpp',['../my__mpu__wrapper_8cpp.html',1,'']]],
  ['my_5fmpu_5fwrapper_2eh_33',['my_mpu_wrapper.h',['../my__mpu__wrapper_8h.html',1,'']]]
];
