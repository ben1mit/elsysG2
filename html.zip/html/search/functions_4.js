var searchData=
[
  ['http_5fsender_5fmain_67',['http_sender_main',['../my__http__sender_8h.html#a13234a168a61d6062bc50d87ceb7a099',1,'http_sender_main(void):&#160;my_http_sender.c'],['../my__http__sender_8c.html#a13234a168a61d6062bc50d87ceb7a099',1,'http_sender_main(void):&#160;my_http_sender.c']]]
];
