var searchData=
[
  ['esp_2didf_20gatt_20server_20spp_20demo_86',['ESP-IDF GATT SERVER SPP demo',['../md_hub_project_components_ble_spp_server__r_e_a_d_m_e.html',1,'']]],
  ['esp_2didf_20spp_20gatt_20client_20demo_87',['ESP-IDF SPP GATT CLIENT demo',['../md_main_project_components_ble_spp_client__r_e_a_d_m_e.html',1,'']]]
];
