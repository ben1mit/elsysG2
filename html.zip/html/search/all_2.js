var searchData=
[
  ['esp_5fgatt_5fuuid_5fspp_5fdata_5freceive_7',['ESP_GATT_UUID_SPP_DATA_RECEIVE',['../ble__spp__server__demo_8c.html#a344e81d261a8f3949cd469ecee393102',1,'ble_spp_server_demo.c']]],
  ['esp_2didf_20gatt_20server_20spp_20demo_8',['ESP-IDF GATT SERVER SPP demo',['../md_hub_project_components_ble_spp_server__r_e_a_d_m_e.html',1,'']]],
  ['esp_2didf_20spp_20gatt_20client_20demo_9',['ESP-IDF SPP GATT CLIENT demo',['../md_main_project_components_ble_spp_client__r_e_a_d_m_e.html',1,'']]]
];
