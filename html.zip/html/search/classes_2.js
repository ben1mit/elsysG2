var searchData=
[
  ['spp_5freceive_5fdata_5fbuff_47',['spp_receive_data_buff',['../structspp__receive__data__buff.html',1,'']]],
  ['spp_5freceive_5fdata_5fnode_48',['spp_receive_data_node',['../structspp__receive__data__node.html',1,'']]]
];
