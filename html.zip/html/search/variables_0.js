var searchData=
[
  ['i2c0_79',['i2c0',['../_i2_cbus_8hpp.html#a169ecf273a21e59d61522712663d1878',1,'i2c0():&#160;I2Cbus.cpp'],['../_i2_cbus_8cpp.html#a169ecf273a21e59d61522712663d1878',1,'i2c0():&#160;I2Cbus.cpp']]],
  ['i2c1_80',['i2c1',['../_i2_cbus_8hpp.html#a4df3b7890b24ee4fa1751dee900f45c0',1,'i2c1():&#160;I2Cbus.cpp'],['../_i2_cbus_8cpp.html#a4df3b7890b24ee4fa1751dee900f45c0',1,'i2c1():&#160;I2Cbus.cpp']]]
];
