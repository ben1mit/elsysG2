var searchData=
[
  ['begin_60',['begin',['../classi2cbus_1_1_i2_c.html#a371a8e03dc4eb5db6b618da998432ce0',1,'i2cbus::I2C']]],
  ['ble_5fclient_5fapp_5fmain_61',['ble_client_app_main',['../spp__client__demo_8h.html#af82cee655f925ff01ed1458b0923e67a',1,'ble_client_app_main():&#160;spp_client_demo.c'],['../spp__client__demo_8c.html#affb82039a33da1b1c0bd27054f2ba28d',1,'ble_client_app_main(void):&#160;spp_client_demo.c']]],
  ['ble_5fmain_62',['ble_main',['../ble__spp__server__demo_8c.html#a4433ce5b860ac517a64bd30618f04b2e',1,'ble_main(void):&#160;ble_spp_server_demo.c'],['../ble__spp__server__demo_8h.html#a4433ce5b860ac517a64bd30618f04b2e',1,'ble_main(void):&#160;ble_spp_server_demo.c']]]
];
