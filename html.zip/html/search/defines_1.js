var searchData=
[
  ['i2c_5fmaster_5fack_5fdis_84',['I2C_MASTER_ACK_DIS',['../_i2_cbus_8cpp.html#a9f4e6d78d28f41a1f861b2022512612c',1,'I2Cbus.cpp']]],
  ['i2c_5fmaster_5fack_5fen_85',['I2C_MASTER_ACK_EN',['../_i2_cbus_8cpp.html#ac2eea8445f1233dbbea456f577d5181c',1,'I2Cbus.cpp']]]
];
