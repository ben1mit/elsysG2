var searchData=
[
  ['gattc_5fprofile_5finst_44',['gattc_profile_inst',['../structgattc__profile__inst.html',1,'']]],
  ['gatts_5fprofile_5finst_45',['gatts_profile_inst',['../structgatts__profile__inst.html',1,'']]]
];
