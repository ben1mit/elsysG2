var searchData=
[
  ['scanner_36',['scanner',['../classi2cbus_1_1_i2_c.html#ac68d13afb8e4f3a8851eaad1f21c7de2',1,'i2cbus::I2C']]],
  ['settimeout_37',['setTimeout',['../classi2cbus_1_1_i2_c.html#aa33df7b828b63b5cb2810eb14cf159b9',1,'i2cbus::I2C']]],
  ['spp_5fclient_5fdemo_2ec_38',['spp_client_demo.c',['../spp__client__demo_8c.html',1,'']]],
  ['spp_5fclient_5fdemo_2eh_39',['spp_client_demo.h',['../spp__client__demo_8h.html',1,'']]],
  ['spp_5freceive_5fdata_5fbuff_40',['spp_receive_data_buff',['../structspp__receive__data__buff.html',1,'']]],
  ['spp_5freceive_5fdata_5fnode_41',['spp_receive_data_node',['../structspp__receive__data__node.html',1,'']]]
];
