var searchData=
[
  ['esp_5fgatt_5fuuid_5fspp_5fdata_5freceive_83',['ESP_GATT_UUID_SPP_DATA_RECEIVE',['../ble__spp__server__demo_8c.html#a344e81d261a8f3949cd469ecee393102',1,'ble_spp_server_demo.c']]]
];
