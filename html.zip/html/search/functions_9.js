var searchData=
[
  ['scanner_75',['scanner',['../classi2cbus_1_1_i2_c.html#ac68d13afb8e4f3a8851eaad1f21c7de2',1,'i2cbus::I2C']]],
  ['settimeout_76',['setTimeout',['../classi2cbus_1_1_i2_c.html#aa33df7b828b63b5cb2810eb14cf159b9',1,'i2cbus::I2C']]]
];
