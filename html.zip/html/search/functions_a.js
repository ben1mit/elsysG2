var searchData=
[
  ['testconnection_77',['testConnection',['../classi2cbus_1_1_i2_c.html#a7fdda3885ae9d66bb4b807daa075c871',1,'i2cbus::I2C']]]
];
